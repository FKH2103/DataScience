from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

# Spark Session with required configurations

spark = SparkSession.builder \
    .appName("AshpazRealtimeProcessing") \
    .config("spark.jars", "jars/kafka-clients-3.5.0.jar,jars/commons-pool2-2.11.1.jar,jars/spark-sql-kafka-0-10_2.12-3.5.0.jar,jars/spark-token-provider-kafka-0-10_2.12-3.5.0.jar") \
    .config("spark.hadoop.fs.file.impl", "org.apache.hadoop.fs.RawLocalFileSystem") \
    .config("spark.sql.streaming.checkpointLocation", "./checkpoint") \
    .config("spark.driver.host", "localhost") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# Schema for incoming orders 

item_schema = StructType([
    StructField("item_id", StringType(), True),
    StructField("unit_price", DoubleType(), True),
    StructField("quantity", IntegerType(), True)
])

order_schema = StructType([
    StructField("order_id", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("restaurant_id", StringType(), True),
    StructField("restaurant_name", StringType(), True),
    StructField("restaurant_city", StringType(), True),
    StructField("cuisines", ArrayType(StringType()), True),
    StructField("phone_number", StringType(), True),
    StructField("request_online", BooleanType(), True),
    StructField("request_table", BooleanType(), True),
    StructField("order_time", StringType(), True),
    StructField("items", ArrayType(item_schema), True),
    StructField("order_price", DoubleType(), True)
])

# 1. Read Kafka Stream (Consumer)

raw_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "ashpaz.order") \
    .option("startingOffsets", "latest") \
    .load()

# Parse JSON and select columns
parsed_df = raw_df.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), order_schema).alias("data")) \
    .select("data.*")

# Convert order_time to timestamp
orders_df = parsed_df.withColumn("event_time", to_timestamp(col("order_time")))


# 2. Real‑Time Operational Analytics 


# Explode cuisines (each order may have multiple cuisines)
cuisine_df = orders_df.withColumn("cuisine", explode(col("cuisines")))

# 2.I. Top Revenue by Cuisine 
revenue_by_cuisine = cuisine_df \
    .withWatermark("event_time", "10 minutes") \
    .groupBy(
        window(col("event_time"), "1 minute", "20 seconds"),
        col("cuisine")
    ) \
    .agg(sum("order_price").alias("total_revenue")) \
    .orderBy(desc("total_revenue"))

# 2.II. Average Order Value per Cuisine 
avg_order_value = cuisine_df \
    .withWatermark("event_time", "10 minutes") \
    .groupBy(
        window(col("event_time"), "1 minute", "20 seconds"),
        col("cuisine")
    ) \
    .agg(avg("order_price").alias("avg_order_value"))


# 3. Real‑Time Fraud Detection System 

# 3.I. Velocity Check (Order Spam) 
# بیش از 5 سفارش در بازه 60 دقیقه
velocity_fraud = orders_df \
    .withWatermark("event_time", "60 minutes") \
    .groupBy(
        window(col("event_time"), "60 minutes"),
        col("user_id")
    ) \
    .count() \
    .filter(col("count") > 5) \
    .select(
        col("user_id"),
        lit("ORDER_SPAM").alias("fraud_reason"),
        col("window")
    )

#  3.II. Geographical Impossibility 
# سفارش در دو شهر مختلف در کمتر از 30 دقیقه
geo_fraud = orders_df \
    .withWatermark("event_time", "30 minutes") \
    .groupBy(
        window(col("event_time"), "30 minutes"),
        col("user_id")
    ) \
    .agg(collect_set("restaurant_city").alias("cities")) \
    .filter(size(col("cities")) > 1) \
    .select(
        col("user_id"),
        lit("GEOGRAPHICAL_IMPOSSIBILITY").alias("fraud_reason"),
        col("window")
    )

# 4. Write Streams (Output)

#  Write Operational Analytics to Kafka Topics 
# تبدیل به JSON برای ارسال به Kafka
def to_json_revenue(df):
    return df.select(
        to_json(struct("window", "cuisine", "total_revenue")).alias("value")
    )

revenue_to_kafka = revenue_by_cuisine.transform(to_json_revenue)

revenue_kafka_query = revenue_to_kafka.writeStream \
    .outputMode("complete") \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "analytics.revenue") \
    .option("checkpointLocation", "./checkpoint/revenue_kafka") \
    .start()

def to_json_avg(df):
    return df.select(
        to_json(struct("window", "cuisine", "avg_order_value")).alias("value")
    )

avg_to_kafka = avg_order_value.transform(to_json_avg)

avg_kafka_query = avg_to_kafka.writeStream \
    .outputMode("complete") \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "analytics.avg") \
    .option("checkpointLocation", "./checkpoint/avg_kafka") \
    .start()

#  Write Fraud Alerts to Dedicated Kafka Topic (orders.fraud_alerts) 
def to_json_velocity(df):
    return df.select(
        to_json(struct("user_id", "fraud_reason", "window")).alias("value")
    )

velocity_to_kafka = velocity_fraud.transform(to_json_velocity)

velocity_kafka_query = velocity_to_kafka.writeStream \
    .outputMode("update") \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "orders.fraud_alerts") \
    .option("checkpointLocation", "./checkpoint/velocity_kafka") \
    .start()

def to_json_geo(df):
    return df.select(
        to_json(struct("user_id", "fraud_reason", "window")).alias("value")
    )

geo_to_kafka = geo_fraud.transform(to_json_geo)

geo_kafka_query = geo_to_kafka.writeStream \
    .outputMode("update") \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "orders.fraud_alerts") \
    .option("checkpointLocation", "./checkpoint/geo_kafka") \
    .start()

#  Also write to console for real‑time monitoring 
revenue_console = revenue_by_cuisine.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .option("checkpointLocation", "./checkpoint/revenue_console") \
    .start()

avg_console = avg_order_value.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .option("checkpointLocation", "./checkpoint/avg_console") \
    .start()

velocity_console = velocity_fraud.writeStream \
    .outputMode("update") \
    .format("console") \
    .option("truncate", False) \
    .option("checkpointLocation", "./checkpoint/velocity_console") \
    .start()

geo_console = geo_fraud.writeStream \
    .outputMode("update") \
    .format("console") \
    .option("truncate", False) \
    .option("checkpointLocation", "./checkpoint/geo_console") \
    .start()

# Await termination (Fault‑tolerant checkpointing active)

spark.streams.awaitAnyTermination()